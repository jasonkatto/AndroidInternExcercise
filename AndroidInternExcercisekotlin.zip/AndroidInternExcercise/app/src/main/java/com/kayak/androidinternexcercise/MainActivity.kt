package com.kayak.androidinternexcercise

import android.content.Intent
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater

import java.util.Arrays

class MainActivity : AppCompatActivity(), RecyclerAdapter.OnNoteListener {


    //create the handler for the recyclerview
    private var recyclerView: RecyclerView? = null

     //images resource id
    private val images = intArrayOf(


            R.drawable.logo_aa, R.drawable.logo_fl, R.drawable.logo_ac, R.drawable.logo_af, R.drawable.logo_as, R.drawable.logo_az, R.drawable.logo_nh, R.drawable.logo_os, R.drawable.logo_ba, R.drawable.logo_sn, R.drawable.logo_dl, R.drawable.logo_ek, R.drawable.logo_ey, R.drawable.logo_f9, R.drawable.logo_b6, R.drawable.logo_kl, R.drawable.logo_lh, R.drawable.logo_sk, R.drawable.logo_lx, R.drawable.logo_ib, R.drawable.logo_tp, R.drawable.logo_tk, R.drawable.logo_ua, R.drawable.logo_us)


    //text resource id
    private val texts = arrayOf(

            "American Airlines", "AirTran", "Air Canada", "Air France", " Alaska Airlines ", " Alitalia", "All Nippon Airways", " austrian Airline", "British Airways", "Brussels Airlines", "Delta Air Lines", "Emirates Airline", "Etihad Arieline", "Frontier", "JetBlue Airways", "KLM", "Lufthansa", "Scandinavian Airway", "Swiss Airway", "Iberia airline", "TAP Air Portugal", "Turkish Airline", "United Airway", "US Airway")

    //create adapter variable
    private var adapter: RecyclerAdapter? = null


    //create layout manager for the recycler view
    private var layoutManager: RecyclerView.LayoutManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //we initialize the handler
        recyclerView = findViewById(R.id.recyclerView)

        //initialize the layout manager
        layoutManager = LinearLayoutManager(this)

        //layoutManager = new GridLayoutManager(this, 2);
        //to improve the performance of layout manager
        recyclerView!!.setHasFixedSize(true)

        //set the layout manager on the recycler view
        recyclerView!!.layoutManager = layoutManager

        //initialize the adapter
        adapter = RecyclerAdapter(images, texts, this)

        //set eh adapter in the recycle view
        recyclerView!!.adapter = adapter

    }


    override fun onNoteClick(position: Int) {

        if (position == 0) {
            val americaAirline = Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://www.aa.com/homePage.do?locale=en_US"))
            startActivity(americaAirline)
        } else if (position == 1) {
            val AirTran = Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://www.alternativeairlines.com/airtran-airways"))
            startActivity(AirTran)
        } else if (position == 2) {

            val AirCanada = Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://www.aircanada.com/en/us/home.html"))
            startActivity(AirCanada)

        } else if (position == 3) {

            val AirFrance = Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://www.airfrance.us"))
            startActivity(AirFrance)

        } else if (position == 4) {

            val AlaskaAirline = Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://www.alaskaair.com"))
            startActivity(AlaskaAirline)

        } else if (position == 5) {

            val Alitalia = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.alitalia.com/en_us/"))
            startActivity(Alitalia)

        } else if (position == 6) {

            val AllNipponAirways = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.ana.co.jp/en/us/"))
            startActivity(AllNipponAirways)

        } else if (position == 7) {

            val austrian = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.austrian.com/?sc_lang=en&cc=US"))
            startActivity(austrian)
        } else if (position == 8) {

            val BritishAirways = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.britishairways.com/en-us/home#/"))
            startActivity(BritishAirways)

        } else if (position == 9) {

            val BrusselsAirlines = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.brusselsairlines.com"))
            startActivity(BrusselsAirlines)

        } else if (position == 10) {

            val DeltaAirLines = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.delta.com"))
            startActivity(DeltaAirLines)

        } else if (position == 11) {

            val EmiratesAirline = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.emirates.com/us/english/"))
            startActivity(EmiratesAirline)

        } else if (position == 12) {

            val EtihadAirways = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.etihadairways.com"))
            startActivity(EtihadAirways)

        } else if (position == 13) {

            val Frontier = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.flyfrontier.com"))
            startActivity(Frontier)

        } else if (position == 14) {

            val JetBlueAirways = Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://www.jetblue.com"))
            startActivity(JetBlueAirways)

        } else if (position == 15) {

            val KLM = Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://www.klm.com"))
            startActivity(KLM)

        } else if (position == 16) {

            val Lufthansa = Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://www.lufthansa.com/us/en/homepage"))
            startActivity(Lufthansa)

        } else if (position == 17) {

            val Scandinavian = Intent(Intent.ACTION_VIEW,
                    Uri.parse("http:// www.flysas.com/us-en/"))
            startActivity(Scandinavian)

        } else if (position == 18) {

            val Swiss = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.swiss.com/usa/EN"))
            startActivity(Swiss)


        } else if (position == 19) {

            val Iberia = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.iberia.com/us/"))
            startActivity(Iberia)

        } else if (position == 20) {

            val TAPAirPortugal = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.flytap.com/USA/en/"))
            startActivity(TAPAirPortugal)

        } else if (position == 21) {

            val Turkish = Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.turkishairlines.com/en-int/"))
            startActivity(Turkish)

        } else if (position == 22) {

            val United = Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://www.united.com"))
            startActivity(United)

        } else if (position == 23) {

            val US = Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://www.usairways.com"))
            startActivity(US)

        }


    }
}
