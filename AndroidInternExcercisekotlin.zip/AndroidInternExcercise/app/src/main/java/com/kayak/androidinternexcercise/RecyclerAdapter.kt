package com.kayak.androidinternexcercise

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.kayak.androidinternexcercise.RecyclerAdapter.ImageViewHolder

class RecyclerAdapter(private val images: IntArray, private val texts: Array<String>, private val mOnNoteListener: OnNoteListener) : RecyclerView.Adapter<RecyclerAdapter.ImageViewHolder>() {

    //to create each item in the recycler view

    override fun onCreateViewHolder(parent: ViewGroup, i: Int): ImageViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.ariline_list, parent, false)
        //return an object of view holder
        return ImageViewHolder(view, mOnNoteListener)


    }


    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {


        val imageId = images[position]
        holder.airlineimg.setImageResource(imageId)

        val textId = texts[position]
        holder.airlineText.text = textId

    }

    override fun getItemCount(): Int {
        return images.size
    }


    interface OnNoteListener {
        fun onNoteClick(position: Int)
    }

    //create separate class fo the view holder
    class ImageViewHolder(itemView: View, internal var onNoteListener: OnNoteListener) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        internal var airlineimg: ImageView
        internal var airlineText: TextView


        init {

            airlineimg = itemView.findViewById(R.id.AirTranimg)
            airlineText = itemView.findViewById(R.id.txtAirTran)
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View) {

            onNoteListener.onNoteClick(adapterPosition)

        }
    }


}
